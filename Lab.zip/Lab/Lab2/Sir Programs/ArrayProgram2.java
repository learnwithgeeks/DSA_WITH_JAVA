public class ArrayProgram2{

     public static void main(String []args){
        int[] mylist=new int[10];
        int[] mylist1=new int[10];
        for(int i=0;i<10;i++){
            mylist[i]=i;
        }
      for (double element: mylist) {
         System.out.println(element);
      }         
         
     }
}