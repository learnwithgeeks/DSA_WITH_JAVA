import java.util.Scanner;
public class LinearSearch{
    public static int linearSearch(int []list,int value){
        int i;
        for(i=0;i<list.length;i++){
            if(list[i]==value){
                return i;                
            }
        }
        return -i;
    }
    public static void main(String[]args)
    {
        int []arr = new int[6];
        Scanner sc = new Scanner(System.in);
        for(int i=0;i<arr.length;i++){
            System.out.print("arr["+i+"]= ");
            arr[i]=sc.nextInt();
        }

        System.out.print("Enter value to search: ");
        int value=sc.nextInt();
        int index=linearSearch(arr,value);

        if(index>=0){
            System.out.println("Element found at index: "+index);
        }
        else{
            System.out.println("Element not found");
        }
    }
}