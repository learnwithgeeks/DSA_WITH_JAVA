import java.util.Scanner;
import java.util.Arrays;
public class BinarySearch{
    public static int binarySearch(int []A,int x,int n){
        int lowerBound=0;
        int upperBound=n-1;
        int midPoint=-1;
        while(lowerBound<=upperBound){
            midPoint = (lowerBound+upperBound)/2;
            if(A[midPoint]==x){
                return midPoint;
            }
            else if(A[midPoint]<x){
                lowerBound = midPoint+1;
            }
            else{
                upperBound = midPoint-1;
            }
        }
        return -midPoint;
        
    }
    public static void main(String[]args)
    {
        int []arr = new int[6];
        Scanner sc = new Scanner(System.in);
        for(int i=0;i<arr.length;i++){
            System.out.print("arr["+i+"]= ");
            arr[i]=sc.nextInt();
        }

        System.out.print("Enter value to search: ");
        int value=sc.nextInt();

        Arrays.sort(arr);

        int index=binarySearch(arr,value,arr.length);

        if(index>=0){
            System.out.println("Element found at index: "+index);
        }
        else{
            System.out.println("Element not found");
        }
    }
}