class Node{
    private Object data;
    Node next;

    public Node(Object object){
        data=object;
    }

    public Object getData(){
        return data;
    }
}