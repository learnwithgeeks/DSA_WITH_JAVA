class playbutton{
  String color;
  int width;
  int height;
  public void onPlay(){
    System.out.println("Play Button");
  }
}
class musicPlayerFrame extends playbutton{
  int height;
  int width;
  public void addComponent(){
  System.out.println("comp added");
  }
}
class Inheritence{
  public static void main(String arg[]){
  musicPlayerFrame f1=new musicPlayerFrame();
  f1.onPlay();
  }
}

