import java.util.*;
public class UseStack{
    public static void pushInStack(Stack<Integer> stack){
        for(int i=1;i<=10;i++){
            stack.push(i);
        }
    }
    public static Integer peekInStack(Stack<Integer> stack){
        return stack.peek();
    }
    public static Integer popInStack(Stack<Integer> stack){
        return stack.pop();
    }
    public static int searchInStack(Stack<Integer> stack,Integer key){ 
        return stack.search(key);
    }
    public static boolean checkEmpty(Stack<Integer> stack){
        return stack.isEmpty();
    }
    public static void main(String[]args)
    {
        Stack<Integer> stack = new Stack<>();
        pushInStack(stack);
        System.out.println("First Element: "+peekInStack(stack));
        System.out.println("Empty: "+checkEmpty(stack));
        System.out.println("Removed Element: "+popInStack(stack));
        int pos = searchInStack(stack,new Integer(5));
        if(pos<0)
            System.out.println("Element not found.");
        else
            System.out.println("Element found, positio is "+pos);
    }
}