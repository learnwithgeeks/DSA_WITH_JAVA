public class BubbleSort{
    public static void bubbleSort(int []arr){
        int temp=0;
        int count=0;
        for(int j=0;j<arr.length;j++){
            //if(!isSorted(arr)){ 
            for(int i=0;i<arr.length-j-1;i++){
                 if(arr[i]>arr[i+1]){
                    temp=arr[i];
                    arr[i]=arr[i+1];
                    arr[i+1]=temp;
                }
                count++;
            }
            //}
            //else{
              //  break;
            //}
        }
        System.out.println(count);
    }
    public static boolean isSorted(int []arr){
        int count=0;
        boolean isSorted=false;
        for(int i=0;i<arr.length-1;i++){
            if(arr[i]<arr[i+1]){
                count++;
                //System.out.println(count);
            }
        }
        if(count==arr.length-2)
            isSorted=true;
        return isSorted;

    }

    public static void main(String[]args)
    {
        int []a={2,6,1,4,15};
        bubbleSort(a);
        //System.out.println(isSorted(a));
        for(int i=0;i<a.length;i++)
            System.out.println("a["+i+"]= "+a[i]);
    }
}