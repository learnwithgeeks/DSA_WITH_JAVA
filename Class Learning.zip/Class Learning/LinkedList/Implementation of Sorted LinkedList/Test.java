public class Test{
    public static void main(String[]args)
    {
        LinkedList list = new LinkedList();
        list.start = list.insert(list.start, 10);
        list.start = list.insert(list.start, 20);
        list.start = list.insert(list.start, 30);
        list.start = list.insert(list.start, 40);
        list.start = list.insert(list.start, 50);

        System.out.println(list.toString());
        System.out.println("Size: "+list.size());

        list.start = list.delete(list.start,40);
        list.start = list.delete(list.start,20);

        System.out.println(list.toString());
        System.out.println("Size: "+list.size());
        System.out.println("Sum: "+list.sum());
        System.out.println("Value at index 0: "+list.get(0));
        System.out.println("Value at index 1: "+list.get(1));
        System.out.println("Value at index 2: "+list.get(2));

        list.start = list.set(list.start,0,20);
        list.start = list.set(list.start,1,40);
        list.start = list.set(list.start,2,60);

        System.out.println(list.toString());
        System.out.println("Index of 60: "+list.getIndex(60));
        System.out.println("Index of 20: "+list.getIndex(20));
        System.out.println("Index of 40: "+list.getIndex(40));


    }
}