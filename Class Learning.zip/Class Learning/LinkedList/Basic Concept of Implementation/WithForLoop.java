public class WithForLoop{
    public static void main(String []args){
        Node start = new Node(11);
        Node p;
        p=start;
        for(int i=2;i<5;i++){
            p=p.next=new Node(11*i);
            if(i==4){
                p=null;
            }
        }

        //access
        int i=0;
        for(Node q=start;q!=null;q=q.next){
            System.out.println("Node "+(i+1)+" : "+q.getData());
        }
    } 
}