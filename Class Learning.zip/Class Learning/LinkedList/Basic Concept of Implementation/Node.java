class Node{
    int data;     //element to be stored
    Node next;   //which holds the address of the next value
    public Node(int data){
        this.data=data;
    }
    public int getData(){
        return data;
    }
}