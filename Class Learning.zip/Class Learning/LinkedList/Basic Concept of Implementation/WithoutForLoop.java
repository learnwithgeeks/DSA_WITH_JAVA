public class WithoutForLoop{
    public static void main(String []args){
        Node start = new Node(11);
        start.next=new Node(22);                    //address of 22 present in 11's next
        start.next.next = new Node(33);             //address of 33 present in 22's next
        start.next.next.next = new Node(44);        //address of 44 present in 33's next
        start.next.next.next.next=null;             //address in 44 is null because it is last element

        System.out.println("Node 1: "+start.getData());
        System.out.println("Node 2: "+start.next.getData());
        System.out.println("Node 3: "+start.next.next.getData());
        System.out.println("Node 4: "+start.next.next.next.getData());
    } 
}