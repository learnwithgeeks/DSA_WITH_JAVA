interface Stack{
    public Object peek();
    public Object pop();
    public void push(Object object);
    public int size();
}