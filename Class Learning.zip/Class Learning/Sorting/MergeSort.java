public class MergeSort{
    public static int[] mergeSort(int[] array){
        if(array.length<=1)
            return array;
        int midpoint = array.length/2;

        int[] left = new int[midpoint];
        int[] right;
        if(array.length%2==0)
            right = new int[midpoint];
        else
            right = new int[midpoint+1];

        //populate the left and right array
        for(int i=0;i<midpoint;i++)
            left[i] = array[i];
        for(int i=0;i<right.length;i++)
            right[i] = array[midpoint+i];
        
        int[] result = new int[array.length];
        
        //Now recursive part
        left = mergeSort(left);
        right = mergeSort(right);

        result = merge(left, right);
        return result;
    }
    private static int[] merge(int[] left, int[] right){
        int[] result = new int[left.length+right.length];

        //pointers for each int array
        int leftPointer, rightPointer, resultPointer;
        leftPointer = rightPointer = resultPointer = 0;

        //while there are elements in either left array or right array we merge them
        while(leftPointer<left.length || rightPointer<right.length){
            //if the elements are in both left and right array
            if(leftPointer<left.length && rightPointer<right.length){
                //compare the left array with the right array
                if(left[leftPointer]<right[rightPointer])
                    result[resultPointer++] = left[leftPointer++];
                else
                    result[resultPointer++] = right[rightPointer++]; 
            }
            else if(leftPointer<left.length){   //if the elements are only in left array
                result[resultPointer++] = left[leftPointer++];
            }
            else if(rightPointer<right.length){   //if the elements are only in right array
                result[resultPointer++] = right[rightPointer++];
            }
        }
        return result;
    }
    public static void main(String[]args)
    {
        int []a={66,33,99,88,44,55,22,77};
        a = mergeSort(a);
        for(int i=0;i<a.length;i++)
            System.out.println("a["+i+"]= "+a[i]);
    }

    // public static void mergeSort(int[] a, int p, int q){
    //     if(q-p<2)
    //         return ;
    //     int m = (p+q)/2;
    //     mergeSort(a,p,m);
    //     mergeSort(a,m,q);
    //     merge(a,p,m,q);
    // }
    // private static void merge(int[] a, int p, int m, int q){
    //     if(a[m-1]<=a[m])
    //         return ;
    //     int i=p,j=m,k=0;
    //     int[] temp = new int[q-p];
    //     while(i<m && j<q){
    //         temp[k++] = (a[i]<a[j] ? a[i++]:a[j++]);
    //     }
    //     System.arraycopy(a, i, a, p+k, m-1);
    //     System.arraycopy(temp, 0, a, p, k);
    // }
}