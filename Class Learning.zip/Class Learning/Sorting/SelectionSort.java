public class SelectionSort{
    public static void selectionSort(int[] a){
        for(int i=0;i<a.length;i++){
            int min=i;
            for(int j=i+1;j<a.length;j++){
                if(a[j]<a[min])
                    min=j;
            }
            if(min!=i){ 
                int temp = a[min];
                a[min] = a[i];
                a[i] = temp;
            }
        }
    }
    public static void main(String[]args)
    {
        int []a={66,33,99,88,44,55,22,77};
        selectionSort(a);
        for(int i=0;i<a.length;i++)
            System.out.println("a["+i+"]= "+a[i]);
    }
}