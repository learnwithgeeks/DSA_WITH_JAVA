public class BubbleSort{
    public static void bubbleSort(int []arr){
        int temp=0;
        int count=0;
        for(int j=0;j<arr.length;j++){
            for(int i=0;i<arr.length-j-1;i++){
                 if(arr[i]>arr[i+1]){
                    temp=arr[i];
                    arr[i]=arr[i+1];
                    arr[i+1]=temp;
                }
                count++;
            }
        }
        System.out.println(count);
    }

    public static void main(String[]args)
    {
        int []a={66,33,99,88,44,55,22,77};
        bubbleSort(a);
        for(int i=0;i<a.length;i++)
            System.out.println("a["+i+"]= "+a[i]);
    }
}