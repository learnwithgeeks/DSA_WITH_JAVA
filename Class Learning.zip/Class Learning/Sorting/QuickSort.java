public class QuickSort{
    public static void quickSort(int[] arr, int low, int high){
        int temp = partition(arr, low, high);
        if(low<temp-1)
            quickSort(arr, low, temp-1);
        if(high>temp)
            quickSort(arr, temp, high);
    }
    private static int partition(int[] arr, int low, int high){
        int pivot = arr[(low+high)/2];

        while(low<=high){
            while(arr[low]<pivot){
                low++;
            }
            while(arr[high]>pivot){
                high--;
            }
            if(low<=high){
                int temp = arr[low];
                arr[low] = arr[high];
                arr[high] = temp;
                low++;
                high--;
            }
        }
        return low;
    } 

    public static void main(String[]args)
    {
        int []a={66,33,99,88,44,55,22,77};
        quickSort(a,0,a.length-1);
        for(int i=0;i<a.length;i++)
            System.out.println("a["+i+"]= "+a[i]);
    }

    // public static void quickSort(int[] a, int p, int q){
    //     if(q-p<2)
    //         return ;
    //     int m = partition(a,p,q);
    //     quickSort(a,p,m);
    //     quickSort(a,m+1,q);
    // }
    // private static int partition(int[] a, int p, int q){
    //     int pivot = a[p], i=p, j=q;
    //     while(i<j){
    //         while(j>i && a[--j]>=pivot) {}
    //         if(j>i)
    //             a[i]=a[j];
    //         while(i<j && a[i++]<=pivot){}
    //         if(i<j)
    //             a[j]=a[i];
    //     }
    //     a[j]=pivot;
    //     return j;
    // }
}